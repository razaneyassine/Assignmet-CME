package com.example.CMEAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmeAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmeAssignmentApplication.class, args);
	}

}
