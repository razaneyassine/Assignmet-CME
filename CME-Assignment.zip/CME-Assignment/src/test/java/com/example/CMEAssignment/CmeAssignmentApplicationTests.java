package com.example.CMEAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmeAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
